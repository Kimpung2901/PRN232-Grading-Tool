using Microsoft.AspNetCore.Http.Json;

var builder = WebApplication.CreateBuilder(args);

builder.WebHost.UseUrls("http://127.0.0.1:5000");
builder.Services.Configure<JsonOptions>(options =>
{
    options.SerializerOptions.PropertyNamingPolicy = null;
});

var app = builder.Build();

var products = new List<Product>();
var nextId = 1;

app.MapGet("/health", () => Results.Ok(new { status = "ok" }));

app.MapGet("/products", () => Results.Ok(products));

app.MapGet("/products/{id:int}", (int id) =>
{
    var product = products.FirstOrDefault(p => p.Id == id);
    return product is null
        ? Results.NotFound(new { message = "Product not found" })
        : Results.Ok(product);
});

app.MapPost("/products", (CreateProductRequest request) =>
{
    if (string.IsNullOrWhiteSpace(request.Name) || request.Price <= 0)
    {
        return Results.BadRequest(new { message = "Invalid product data" });
    }

    var product = new Product(nextId++, request.Name.Trim(), request.Price);
    products.Add(product);

    return Results.Created($"/products/{product.Id}", product);
});

app.Run();

internal record Product(int Id, string Name, decimal Price);

internal record CreateProductRequest(string Name, decimal Price);
